package com.chen.movie.service;

import com.chen.movie.domain.User;

public interface MovieService {

    User findUserById(Long id);

}
